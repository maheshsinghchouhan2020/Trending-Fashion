import logo from "../img/logo.png";
import hero from "../img/hero4.png"
import buttonpng from "../img/button.png";
import offerbaner from '../img/banner/b2.jpg';
import CrazyDeals from'../img/banner/b10.jpg';
import upcomingSeasone from'../img/banner/b17.jpg';
import seasoneSale from '../img/banner/b7.jpg';
import winterJocket from '../img/banner/b4.jpg';
import Tshirts from '../img/banner/b18.jpg';
import NewsLatter from "../img/banner/b14.png";
import appIcon from "../img/pay/app.jpg";
import payIcon from '../img/pay/pay.png';
import PlayIcon from "../img/pay/play.jpg";
import WhoWeAre from "../img/about/a6.jpg";
export {
  logo,
  hero,
  buttonpng,
  offerbaner,
  CrazyDeals,
  upcomingSeasone,
  seasoneSale,
  winterJocket,
  Tshirts,
  NewsLatter,
  payIcon,
  PlayIcon,
  appIcon,
  WhoWeAre,
}

