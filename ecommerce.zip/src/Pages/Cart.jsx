import React from 'react'
import Cartitems from './Cartitems';

const Cart = () => {
  return (
    <div >
<Cartitems/>
    </div>
  )
}

export default Cart;
