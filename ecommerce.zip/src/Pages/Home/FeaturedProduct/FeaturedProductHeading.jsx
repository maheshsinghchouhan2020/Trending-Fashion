import React from 'react'

const FeaturedProductHeading = () => {
  return (
    <section class="product-heading">
    <h2>Featured Products</h2>
        <p>Summer collection New modern design</p>
      </section>
  )
}

export default FeaturedProductHeading
