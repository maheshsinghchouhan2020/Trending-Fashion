import React from 'react'

const NewArrival = () => {
  return (
    <section class="product-heading">
    <h2>New Arrivals</h2>
    <p>Summer collection New modern design</p>
    </section>
  )
}

export default NewArrival
