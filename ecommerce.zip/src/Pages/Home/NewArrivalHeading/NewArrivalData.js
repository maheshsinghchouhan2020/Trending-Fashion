import N1 from "../../../assets/img/products/n1.jpg";
import N2 from "../../../assets/img/products/n2.jpg";
import N3 from "../../../assets/img/products/n3.jpg";
import N4 from "../../../assets/img/products/n4.jpg";
import N5 from "../../../assets/img/products/n5.jpg";
import N6 from "../../../assets/img/products/n6.jpg";
import N7 from "../../../assets/img/products/n7.jpg";
import N8 from "../../../assets/img/products/n8.jpg";

let NewArrivalData = [
  {
    id: 1,
    image: N1,
    brand: "Nike",
    name: "New Arrival shirt",
    Price: 111,
  },
  {
    id: 2,
    image: N2,
    brand: "Tommy hilfiger",
    name: "New Arrival shirt",
    Price: 150,
  },
  {
    id: 3,
    image: N3,
    brand: "Peter England",
    name: "New Arrival shirt",
    Price: 160,
  },
  {
    id: 4,
    image: N4,
    brand: "Gucci",
    name: "New Arrival shirt",
    Price: 55,
  },
  {
    id: 5,
    image: N5,
    brand: "H&M",
    name: "New Arrival shirt",
    Price: 199,
  },
  {
    id: 6,
    image: N6,
    brand: "ZARA",
    name: "New Arrival shirt",
    Price: 59,
  },
  {
    id: 7,
    image: N7,
    brand: "reebok",
    name: "New Arrival shirt",
    Price: 79,
  },
  {
    id: 8,
    image: N8,
    brand: "puma",
    name: "New Arrival shirt",
    Price: 99,
  },
];

export default NewArrivalData;
