import React from 'react'
import NewProduct from '../Home/NewArrivalHeading/NewProduct'

const RelatedProduct = () => {
  return (
    <div className='Related-Product'>
        <h1>Related Product</h1>
            <NewProduct />
    </div>
  )
}

export default RelatedProduct
