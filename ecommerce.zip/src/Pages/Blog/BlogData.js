import blog1 from "../../assets/img/blog/b1.jpg";
import blog2 from "../../assets/img/blog/b2.jpg";
import blog3 from "../../assets/img/blog/b3.jpg";
import blog4 from "../../assets/img/blog/b4.jpg";
import blog5 from "../../assets/img/blog/b5.jpg";


let BlogData = [
    {
        image : blog1,
        heading :"The cotton-jersey Zip-Up Hoodie" ,
        description : "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Delectus sapiente cum repellendus eius eum alias rerum? Officia fugit hic obcaecati? Obcaecati eius temporibus reprehenderit vitae, quocorrupti! Quia, tempora amet.",
        More : "Continue Reading",
        date : "13/01",
    },
    {
        image : blog2,
        heading : "The cotton-jersey Zip-Up Hoodie",
        description : "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Delectus sapiente cum repellendus eius eum alias rerum? Officia fugit hic obcaecati? Obcaecati eius temporibus reprehenderit vitae, quocorrupti! Quia, tempora amet.",
        More : "Continue Reading",
        date : "13/02",
    },
    {
        image : blog3,
        heading : "The cotton-jersey Zip-Up Hoodie",
        description : "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Delectus sapiente cum repellendus eius eum alias rerum? Officia fugit hic obcaecati? Obcaecati eius temporibus reprehenderit vitae, quocorrupti! Quia, tempora amet.",
        More : "Continue Reading",
        date : "13/03",
    },
    {
        image : blog4,
        heading : "The cotton-jersey Zip-Up Hoodie",
        description : "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Delectus sapiente cum repellendus eius eum alias rerum? Officia fugit hic obcaecati? Obcaecati eius temporibus reprehenderit vitae, quocorrupti! Quia, tempora amet.",
        More : "Continue Reading",
        date : "13/04",
    },
    {
        image : blog5,
        heading : "The cotton-jersey Zip-Up Hoodie",
        description : "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Delectus sapiente cum repellendus eius eum alias rerum? Officia fugit hic obcaecati? Obcaecati eius temporibus reprehenderit vitae, quocorrupti! Quia, tempora amet.",
        More : "Continue Reading",
        date : "13/05",
    }
]

export default BlogData;